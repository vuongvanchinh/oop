import java.util.ArrayList;
import java.util.List;


public class Layer {
   private List<Shape> shapes = new ArrayList<>();

   /**
    *  add new shape.
    * @param newShape new shape.
    */
   public void addShape(Shape newShape) {
      this.shapes.add(newShape);
   }

   /**
    * remove.
    */
   public void removeCircles() {
      int i = 0;
      while (i < shapes.size()) {
         if (shapes.get(i) instanceof Circle) {
            shapes.remove(i);
         } else {
            i++;
         }
      }
   }

   /**
    * get information.
    * @return string.
    */
   public String getInfo() {
      StringBuilder sb = new StringBuilder();
      sb.append("Layer of crazy shapes: \n");
      for (Shape shape : shapes) {
         sb.append(shape.toString() + "\n");
      }
      return sb.toString();
   }

   /**
    * remove duplicate shape.
    */
   public void removeDuplicates() {
      int i = 0;
      int j = 0;
      while (i < shapes.size()) {
         j = i + 1;
         while (j < shapes.size()) {
            if (shapes.get(i).equals(shapes.get(j))) {
               shapes.remove(j);
            } else {
               j++;
            }
         }
         i++;
      }
   }
}
