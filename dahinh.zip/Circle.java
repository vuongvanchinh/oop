public class Circle extends Shape {
   protected double radius;
   protected Point center;

   @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof Circle)) {
            return false;
        }
        Circle circle = (Circle) o;
        return radius == circle.radius && center.equals(circle.center);
   }

   @Override
   public int hashCode() {
      return this.hashCode();
   }

   public Point getCenter() {
      return this.center;
   }

   public void setCenter(Point center) {
      this.center = center;
   }

   public Circle() {
      this.radius = 0;
   }

   /**
    * constructor.
    * @param radius radius of circle.
    */
   public Circle(double radius) {
      this.radius = radius;
   }

   /**
    * initialize.
    * @param radius radius of circle.
    * @param color color of circle.
    * @param filled is filled circle.
    */
   public Circle(double radius, String color, boolean filled) {
      super(color, filled);
      this.radius = radius;
   }

    /**
    * initialize.
    * @param center center.
    * @param radius radius of circle.
    * @param color color of circle.
    * @param filled is filled circle.
    */
    public Circle(Point center, double radius, String color, boolean filled) {
      super(color, filled);
      this.radius = radius;
      this.center = new Point(center.getPointX(), center.getPointY());
   }


   public double getRadius() {
      return this.radius;
   }

   public void setRadius(double radius) {
      this.radius = radius;
   }

   public double getArea() {
      return Math.PI * radius * radius;
   }

   public double getPerimeter() {
      return 2 * Math.PI * radius;
   }

   public String toString() {
      return String.format("Circle[center=%s,radius=%.1f,color=%s,filled=%b]",
         this.center.toString(), this.getRadius(), this.getColor(), this.filled);
   }
}
