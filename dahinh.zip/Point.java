public class Point {
   private double pointX;
   private double pointY;
   
   /**
    * constructor.
    * @param pointX x.
    * @param pointY y.
    */
   public Point(double pointX, double pointY) {
      this.pointX = pointX;
      this.pointY = pointY;
   }

   public double getPointX() {
      return this.pointX;
   }

   public void setPointX(double pointX) {
      this.pointX = pointX;
   }

   public double getPointY() {
      return this.pointY;
   }

   public void setPointY(double pointY) {
      this.pointY = pointY;
   }

   /**
    * calculator.
    * @param x point.
    * @return distance between two point.
    */
   public double distance(Point x) {
      double a = (this.pointX - x.pointX) * (this.pointX - x.pointX);
      double b = (this.pointX - x.pointX) * (this.pointX - x.pointX);
      return Math.sqrt(a + b);
   } 

   /**
    * compare.
    */
   public boolean equals(Object o) {
      if (this == o) {
         return true;
      }
      if (o == null || o.getClass() != this.getClass()) {
         return false;
      }
      Point temp = (Point) o;
      return Math.abs(this.pointX - temp.pointX) <= 0.001
         && Math.abs(this.pointY - temp.pointY) <= 0.001;
   }

   @Override
   public int hashCode() {
      return this.hashCode();
   }

   public String toString() {
      return String.format("(%.1f,%.1f)", this.pointX, this.pointY);
   } 

   // public static void main(String[] args) {
   //    Point p = new Point(10,10.5);
   //    System.out.println(p.toString());
   // }
}
