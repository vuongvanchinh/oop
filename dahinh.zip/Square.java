public class Square extends Rectangle {

   public Square() {
   }

   public Square(double side) {
      this.setSide(side);
   }

   /**
    * initialize square.
    * @param side side of square.
    * @param color color of square.
    * @param filled filled boolean.
    */
   public Square(double side, String color, boolean filled) {
      setLength(side);
      setWidth(side);
      this.color = color;
      this.filled = filled;
   }

    /**
    * initialize square.
    * @param topLeft topLeft.
    * @param side side of square.
    * @param color color of square.
    * @param filled filled boolean.
    */
    public Square(Point topLeft, double side, String color, boolean filled) {
      setLength(side);
      setWidth(side);
      this.color = color;
      this.filled = filled;
      this.topLeft = new Point(topLeft.getPointX(), topLeft.getPointY());
   }

   public double getSide() {
      return this.width;
   }

   public void setSide(double side) {
      this.length = side;
      this.width = side;
   }

   public void setWidth(double width) {
      this.setSide(width);
   }

   public void setLength(double length) {
       this.setSide(length);
   }

   public String toString() {
      return String.format("Square[topLeft=%s,side=%.1f,color=%s,filled=%b]",
         topLeft.toString(), this.getSide(), this.getColor(), this.isFilled());
   }

   @Override
   public boolean equals(Object o) {
       if (o == this) {
           return true;
       }
       if (!(o instanceof Square)) {
           return false;
       }
       Square square = (Square) o;
       return Math.abs(this.width - square.width) <= 0.001 && topLeft.equals(square.topLeft);
  }
}
