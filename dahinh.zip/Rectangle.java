public class Rectangle extends Shape {
   protected double width;
   protected double length;
   protected Point topLeft;

   public Point getTopLeft() {
      return this.topLeft;
   }

   public void setTopLeft(Point topLeft) {
      this.topLeft = topLeft;
   }

   /**
    * instructor.
    * @param width w.
    * @param length l.
    * @param topLeft tl.
    */
   public Rectangle(double width, double length, Point topLeft) {
      this.width = width;
      this.length = length;
      this.topLeft = topLeft;
   }

   public Rectangle() {
      this.length = 0;
      this.width = 0;
   }

   /**
    * initialize.
    * @param width the width of rectangle.
    * @param length the length of rectangle.
    */
   public Rectangle(double width, double length) {
      this.width = width;
      this.length = length;
   }

   /**
    * initialize.
    * @param width width.
    * @param length length.
    * @param color color.
    * @param filled filled.
    */
   public Rectangle(double width, double length, String color, boolean filled) {
      super(color, filled);
      this.width = width;
      this.length = length;
   }

   /**
   * initialize.
   * @param topLeft topLeft.
   * @param width width.
   * @param length length.
   * @param color color.
   * @param filled filled.
   */
   public Rectangle(Point topLeft, double width, double length, String color, boolean filled) {
      super(color, filled);
      this.width = width;
      this.length = length;
      this.topLeft = new Point(topLeft.getPointX(), topLeft.getPointY());
   }

   public double getWidth() {
      return this.width;
   }

   public void setWidth(double width) {
      this.width = width;
   }

   public double getLength() {
      return this.length;
   }

   public void setLength(double length) {
      this.length = length;
   }

   public double getArea() {
      return length * width;
   }

   public double getPerimeter() {
      return 2 * (length + width);
   }

   public String toString() {
      return String.format("Rectangle[topLeft=%s,width=%.1f,length=%.1f,color=%s,filled=%b]",
         this.topLeft.toString(), this.getWidth(), this.getLength(), this.getColor(), this.filled);
   }

   @Override
   public boolean equals(Object o) {
       if (o == this) {
           return true;
       }
       if (!(o instanceof Rectangle)) {
           return false;
       }
       Rectangle rectangle = (Rectangle) o;
       return Math.abs(width - rectangle.width) <= 0.001
       && Math.abs(length - rectangle.length) <= 0.001
       && topLeft.equals(rectangle.topLeft);
  }

  @Override
  public int hashCode() {
     return this.hashCode();
  }
}
